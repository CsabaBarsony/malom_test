const Company = createReactClass({
  render: function() {
    return React.createElement('div', null, 'előtag, társaság')
  }
})
